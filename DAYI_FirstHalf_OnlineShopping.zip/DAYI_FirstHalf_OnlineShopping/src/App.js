import React from "react";
import logo from "./logo.svg";
import "./App.css";
import ListOfProducts from './listofproducts.component';

class App extends React.Component {
  
  render() {
    return (
      <ListOfProducts />
    );
    // babel JS converts JSX to React API !
  }
}

export default App;
