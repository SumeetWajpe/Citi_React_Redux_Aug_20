import React from "react";
import "./product.css";

export default class Product extends React.Component {
    constructor(){
        super();
        this.state = {counter:100};
    }
  IncrementLikes() {
      // props -> this.props.productdetails.likes++
      //this.props.productdetails.likes++; //props are read only !
      // state ! -> private to  every component, an Object !
    //   this.state.counter++; // state is immutable !
    this.setState({counter:this.state.counter + 1});
  }
  render() {
    return (
      <div className="col-md-4">
        <div className="productStyle">
          <h1>{this.props.productdetails.title}</h1>
          <img
            src={this.props.productdetails.ImageUrl}
            height="100px"
            width="100px"
          />{" "}
          <br />
          <strong>Price : </strong> {this.props.productdetails.price} <br />
          <strong>Quantity : </strong> {this.props.productdetails.quantity}{" "}
          <br />
          <strong>Rating : </strong> {this.props.productdetails.rating} <br />
          <button
            className="btn btn-primary"
            onClick={this.IncrementLikes.bind(this)}
          >
            <span className="glyphicon glyphicon-thumbs-up"></span>
            {this.state.counter}
            {/* {this.props.productdetails.likes} */}
          </button>{" "}
          <br />
        </div>
      </div>
    );
  }
}
