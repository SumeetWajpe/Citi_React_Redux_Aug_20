import React from "react";
import "./product.css";

export default class Product extends React.Component {
    constructor(props){
        super(props);
        this.state = {counter:this.props.productdetails.likes};
        //console.log('Within Constructor !');
    }
    componentWillMount(){
        // Any initialization
        //console.log('Within componentWillMount !');

    }
    componentDidMount(){
        // Integrate with other lib / AJAX
        //console.log('Within componentDidMount !');
    }
    shouldComponentUpdate(){
        // gets called whenever state updates
        //console.log('Within shouldComponentUpdate !');
        //return false; // if u don't want unnecessary re-renders
        return true;
    }
    componentWillUpdate(){
        //console.log('Within componentWillUpdate !');
    }
    componentDidUpdate(){
        //console.log('Within componentDidUpdate !');
    }
  IncrementLikes() {
      // props -> this.props.productdetails.likes++
      //this.props.productdetails.likes++; //props are read only !
      // state ! -> private to  every component, an Object !
    //   this.state.counter++; // state is immutable !
    //console.log('Within IncrementLikes !');
    this.setState({counter:this.state.counter + 1});
  }
  render() {
    //console.log('Within Render !');      
    return (
      <div className="col-md-4">
        <div className="productStyle">
          <h1>{this.props.productdetails.title}</h1>
          <img
            src={this.props.productdetails.ImageUrl}
            height="100px"
            width="100px"
          />{" "}
          <br />
          <strong>Price : </strong> {this.props.productdetails.price} <br />
          <strong>Quantity : </strong> {this.props.productdetails.quantity}{" "}
          <br />
          <strong>Rating : </strong> {this.props.productdetails.rating} <br />
          <button
            className="btn btn-primary"
            onClick={this.IncrementLikes.bind(this)}
          >
            <span className="glyphicon glyphicon-thumbs-up"></span>
            {this.state.counter}
            {/* {this.props.productdetails.likes} */}
          </button>{" "}
          <br />
        </div>
      </div>
    );
  }
}
