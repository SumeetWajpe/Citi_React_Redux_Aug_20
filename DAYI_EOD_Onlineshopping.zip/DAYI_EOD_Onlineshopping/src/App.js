import React from "react";
import logo from "./logo.svg";
import "./App.css";
import ListOfProducts from './listofproducts.component';
import Posts from './posts.component';

class App extends React.Component {
  
  render() {
    return (
      // <ListOfProducts />
      <Posts />
    );
    // babel JS converts JSX to React API !
  }
}

export default App;
