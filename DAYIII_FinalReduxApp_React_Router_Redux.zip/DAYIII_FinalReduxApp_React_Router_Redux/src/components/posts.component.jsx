import React from "react";
import axios from "axios";
import { Link } from "react-router-dom";

class Posts extends React.Component {  
  componentDidMount() {
    axios
      .get("https://jsonplaceholder.typicode.com/posts")
      .then((response) => this.props.FetchPosts(response.data) );
  }
  render() {
      console.log(this.props);
    var allPosts = this.props.allPosts.map((post) => 
    <li key={post.id}><Link to={"/postdetails/" + post.id}>{post.title}</Link></li>);
    return (
      <React.Fragment>
        <h1>All Posts !</h1>
        <ul>{allPosts}</ul>
      </React.Fragment>
    );
  }
}
// <Link to={"/postdetails/" + post.id}>{post.title}</Link>
export default Posts;
