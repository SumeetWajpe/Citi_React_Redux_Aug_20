import React from 'react';
import ListOfProducts from './listofproducts.component';
import Posts from './posts.component';
import { BrowserRouter, Switch, Route, Redirect, Link } from "react-router-dom";
import PostDetails from './postdetails.component';

function App(props) {
  // allProducts , allPosts , IncrementLikes(), DeleteProduct()
  return (
    <BrowserRouter>
    <nav className="navbar navbar-inverse">
      <div className="container-fluid">
        <div className="navbar-header">
          <Link className="navbar-brand" to="/">
            Online Shopping
          </Link>
        </div>
        <ul className="nav navbar-nav">
          <li>
            {" "}
            <Link to="/"> Shopping Cart</Link>
          </li>
          <li>
            <Link to="/posts"> Posts </Link>{" "}
          </li>
        </ul>
      </div>
    </nav>
    <Switch>
      <Route path="/" exact render={()=> <ListOfProducts {...props} />} ></Route>
      <Route path="/posts" render={()=> <Posts {...props} /> }></Route>
      <Route path="/postdetails/:pid"
       render={(routerprops)=> <PostDetails {...props} {...routerprops} />} />
      <Route path="**" render={() => <Redirect to="/" />}></Route>
    </Switch>
  </BrowserRouter>

  );
}

export default App;
