import React from "react";
import Product from "./product.component";

class ListOfProducts extends React.Component {
  render() {
    let productsToBeCreated = this.props.allProducts.map((p) => (
      <Product productdetails={p} key={p.id} {...this.props} />
    ));
    return (
      <React.Fragment>
        <div className="jumbotron">
          <h1>Online Shopping</h1>
        </div>
        <div className="row">
          {productsToBeCreated}
        </div>
      </React.Fragment>

    );
    // babel JS converts JSX to React API !
  }
}

export default ListOfProducts;
