export function IncrementLikes(theId){
    return {type:'INCREMENT_LIKES',theId}
}
export function DeleteProduct(theId){
    return {type:'DELETE_PRODUCT',theId}
}

export function FetchPosts(response){
    return {type:'FETCH_POSTS',response  }
}