var theIndex;
var theId;
export function products(storeData=[],action){
    switch(action.type){
        case 'INCREMENT_LIKES':
            //??? id !
             theId = action.theId;
            theIndex = storeData.findIndex(p=>p.id === theId)
            return [
                ...storeData.slice(0,theIndex),
                {...storeData[theIndex],likes:storeData[theIndex].likes+1},
                ...storeData.slice(theIndex+1)
            ] // return a newer store value

            case 'DELETE_PRODUCT':
                theId = action.theId;
                theIndex = storeData.findIndex(p=>p.id === theId)
                return [
                    ...storeData.slice(0,theIndex),                    
                    ...storeData.slice(theIndex+1)
                ] // return a newer store value
        default:
            return storeData;
    }
}