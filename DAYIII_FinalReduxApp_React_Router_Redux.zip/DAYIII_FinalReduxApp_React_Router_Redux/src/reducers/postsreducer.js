export function posts(storeData=[],action){
    switch(action.type){
        case 'ADD_POST':
            console.log(action);
        return storeData; // return a newer store value
        case 'FETCH_POSTS':
            return action.response;
            // return response data
        default:            
            return storeData;
    }
}