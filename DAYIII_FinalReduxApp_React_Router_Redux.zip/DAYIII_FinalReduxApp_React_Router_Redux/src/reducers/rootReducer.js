import {combineReducers} from 'redux';
import {posts} from './postsreducer';
import {products} from './productsreducer';

var rootReducer = combineReducers({posts:posts,products});
export default rootReducer;