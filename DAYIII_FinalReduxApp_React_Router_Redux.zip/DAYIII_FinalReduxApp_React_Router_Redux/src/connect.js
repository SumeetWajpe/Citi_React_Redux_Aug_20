import {connect} from 'react-redux';
import { bindActionCreators } from 'redux';
import * as AllActions from './actions/actionCreators';
import App from './components/App';

function mapDispatchToProps(dispatcherObj){
    // map actions as props
    return bindActionCreators(AllActions,dispatcherObj);
}

function mapStateToProps(storeData){ // by the Provider
    // map store data as props
    return {
        allProducts:storeData.products,
        allPosts:storeData.posts
    }
}

var MainApp = connect(mapStateToProps,mapDispatchToProps)(App);
export default MainApp;