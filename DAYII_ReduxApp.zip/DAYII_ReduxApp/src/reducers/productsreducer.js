export function products(storeData=[],action){
    switch(action.type){
        case 'INCREMENT_LIKES':
            console.log(action);
        return storeData; // return a newer store value
        default:
            return storeData;
    }
}