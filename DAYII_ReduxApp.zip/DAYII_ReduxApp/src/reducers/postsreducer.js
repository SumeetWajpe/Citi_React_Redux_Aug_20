export function posts(storeData=[],action){
    switch(action.type){
        case 'ADD_POST':
            console.log(action);
        return storeData; // return a newer store value
        default:
            return storeData;
    }
}