import {combineReducers} from 'redux';
import {posts} from './postsreducer';
import {products} from './productsreducer';

var rootReducer = combineReducers({posts,products});
export default rootReducer;