export function IncrementLikes(){
    return {type:'INCREMENT_LIKES'}
}
export function DeleteProduct(){
    return {type:'DELETE_PRODUCT'}
}