import React from 'react';
import { render } from '@testing-library/react';
import App from './App';
import Enzyme,{shallow} from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';

Enzyme.configure({ adapter: new Adapter() });

describe('Testing App Component',function(){
  it('tests if counter state is equal to zero',function(){
    // App instance
    var appInstance = shallow(<App/>);
    var initialCount =appInstance.state().counter;
    expect(initialCount).toEqual(0)
  });

  it('checks if counter increments by 1',function(){
    var appInstance = shallow(<App/>);
    var btn = appInstance.find('button');
    btn.simulate('click');
    var pText = appInstance.find('p').text();
    expect(pText).toEqual('Count : 1')
  })
})
