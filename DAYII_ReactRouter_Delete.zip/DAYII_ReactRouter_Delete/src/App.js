import React from "react";
import logo from "./logo.svg";
import "./App.css";
import ListOfProducts from "./listofproducts.component";
import Posts from "./posts.component";
import { BrowserRouter, Switch, Route, Redirect, Link } from "react-router-dom";
import PostDetails from "./postdetails.component";

class App extends React.Component {
  render() {
    return (
      <BrowserRouter>
        <nav className="navbar navbar-inverse">
          <div className="container-fluid">
            <div className="navbar-header">
              <Link className="navbar-brand" to="/">
                Online Shopping
              </Link>
            </div>
            <ul className="nav navbar-nav">
              <li>
                {" "}
                <Link to="/"> Shopping Cart</Link>
              </li>
              <li>
                <Link to="/posts"> Posts </Link>{" "}
              </li>
            </ul>
          </div>
        </nav>

        <Switch>
          <Route path="/" exact component={ListOfProducts}></Route>
          <Route path="/posts" component={Posts}></Route>
          <Route path="/postdetails/:pid" component={PostDetails} />
          <Route path="**" render={() => <Redirect to="/" />}></Route>
        </Switch>
      </BrowserRouter>
    );
    // babel JS converts JSX to React API !
  }
}

export default App;
