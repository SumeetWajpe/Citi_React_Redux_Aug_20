import React from 'react'

class PostDetails extends React.Component {
    render(){
        const {match:{params}} = this.props;
        console.log(params.pid);
        return(
            <div>
                <h1> Post Details for {params.pid} </h1>
            </div>
        )
    }
    
}

export default PostDetails