import React from "react";
import axios from "axios";
import { Link } from "react-router-dom";

// // 1. Can't use State
// // 2. No life cycle hooks
// // 3. No ctor / render !
// export const Message = () => {
//     return(
//         <div>
//             <h1>Functional Component !</h1>
//         </div>
//     )
// }

// ajax request ->
// register callback ->
// get the reponse & update the UI !
//===========
// 1. Define - state -> posts : []
// 2. Render() -> map -> posts
// 3. When u receive data then setState

class Posts extends React.Component {
  constructor(props) {
    super(props);
    this.state = { posts: [] };
  }
  componentDidMount() {
    axios
      .get("https://jsonplaceholder.typicode.com/posts")
      .then((response) => this.setState({posts:response.data}));
  }
  render() {
    var allPosts = this.state.posts.map((post) => <li key={post.id}><Link to={"/postdetails/" + post.id}>{post.title}</Link></li>);
    return (
      <React.Fragment>
        <h1>All Posts !</h1>
        <ul>{allPosts}</ul>
      </React.Fragment>
    );
  }
}

export default Posts;
